Apollo impact versus pre-impact controls

Contents:
- apollo_impact_control_three_station.png: RMS comparisons for Apollo 16 S15 and Apollo 17 S15/S16
- impact_control_summary.json: processing, results, uncertainty, and limitations

These are exploratory results. See the JSON limitations before citing or interpreting them.
